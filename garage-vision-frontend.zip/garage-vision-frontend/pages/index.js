export default function Home() {
  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold">Garage-Vision</h1>
      <p>Welcome to Garage-Vision. Visit pages: Features, Pricing, Hardware Kits, Case Studies, Contact, Login.</p>
    </div>
  );
}
